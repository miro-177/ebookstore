package uga.edu.cs.finalProjectDBMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProjectDbmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalProjectDbmsApplication.class, args);
	}

}

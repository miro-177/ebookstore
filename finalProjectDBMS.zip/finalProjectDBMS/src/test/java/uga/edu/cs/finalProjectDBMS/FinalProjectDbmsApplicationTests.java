package uga.edu.cs.finalProjectDBMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectDbmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
